"""
Tests meant to be run with pytest
"""

import pytest

from moviepy.editor import *


@pytest.fixture
def example_video1():
	
