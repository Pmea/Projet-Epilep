Advanced tools
===============

This section briefly presents a few functions of the submodule ``moviepy.video.tools``
that can help you edit videos. See the documentation for each modu

Subtitles
----------

Credits 