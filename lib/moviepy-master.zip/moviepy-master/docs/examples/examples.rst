.. _examples:

Example Scripts
===============

Here are a few example scripts to get you started. Most are quite old now and will be soon replaced.


.. toctree::
   :maxdepth: 1
   
   moving_letters
   dancing_knights
   ukulele_concerto
   example_with_sound
   star_worms
   masked_credits
   painting_effect
   compo_from_image
   the_end
   
   
   
   
