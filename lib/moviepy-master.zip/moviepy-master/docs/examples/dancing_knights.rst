==========================================
A reconstitution of 15th century dancing
==========================================

And now for something very silly...

.. raw:: html

        <div style="position: relative; padding-bottom: 56.25%; padding-top: 30px; margin-bottom:30px; height: 0; overflow: hidden; 
         margin-left: 5%;">
        <iframe src="http://youtube.com/v/Qu7HJrsEYFg?rel=0" frameborder="0" allowfullscreen
        style="position: absolute; top: 0; bottom: 10; width: 90%; height: 100%;">
        </iframe>
        </div>

.. literalinclude:: ../../examples/dancing_knights.py


