======================
A simple music video
======================

.. raw:: html

        <center>
        <object><param name="movie"
        value="http://www.youtube.com/v/AqGZ4JFkQTU&hl=en_US&fs=1&rel=0">
        </param><param name="allowFullScreen" value="true"></param><param
        name="allowscriptaccess" value="always"></param><embed
        src="http://www.youtube.com/v/AqGZ4JFkQTU&hl=en_US&fs=1&rel=0"
        type="application/x-shockwave-flash" allowscriptaccess="always"
        allowfullscreen="true" width="550" height="450"></embed></object>
        </center>


This is an example, with no sound (lame for a music video), soon to be
replaced with a real music video example (the code will be 99% the same).
The philosophy of MoviePy is that for each new music video I will make,
I will just have to copy/paste this code, and modify a few lines.

.. literalinclude:: ../../examples/ukulele_concerto.py
