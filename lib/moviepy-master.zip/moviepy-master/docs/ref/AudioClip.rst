.. ref_AudioClip:

************
AudioClip
************

:class:`AudioClip`
==========================

.. autoclass:: moviepy.audio.AudioClip.AudioClip
   :members:
   :show-inheritance:

:class:`AudioFileClip`
==========================

.. autoclass:: moviepy.audio.io.AudioFileClip.AudioFileClip
   :members:
   :show-inheritance:
   

:class:`CompositeAudioClip`
================================

.. autoclass:: moviepy.audio.AudioClip.CompositeAudioClip
   :members:
   :show-inheritance:

