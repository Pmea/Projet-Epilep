moviepy.video.fx.all.painting
=============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: painting