moviepy.video.fx.all.speedx
===========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: speedx