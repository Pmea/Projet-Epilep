moviepy.video.fx.all.make_loopable
==================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: make_loopable