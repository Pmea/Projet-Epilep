moviepy.video.fx.all.crop
=========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: crop