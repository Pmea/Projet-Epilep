moviepy.video.fx.all.fadeout
============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: fadeout